<?php
  include("functions.php");

  include("views/header.php");

  include("views/home.php");
  
  include("views/footer.php");









?>